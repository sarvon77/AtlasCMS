
<!DOCTYPE html>
<html>
  <head>
    <title>Atlas oil</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
		<link href="css/boot-business.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, user-scalable=no" />
	 <!--<link href="css/bootstrap-theme.min.css" rel="stylesheet">-->
  </head>
  <style>
.Absolute-Center {
  height: 38%;
  margin: auto;
  position: absolute;
  top: 0; left: 0; bottom: 0; right: 0;
}


  </style>
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/boot-business.js"></script>
<body>
<header>
      <!-- Start: Navigation wrapper -->
		<div class="navbar navbar-fixed-top">
			<div class="navbar-inner" style="">
				<div class="container">
					<a href="index.php" class="brand brand-bootbus"><img src="img/Atlas_New.png" style="height: 54px;"></a>
					 <!-- Below button used for responsive navigation -->
					
           
				</div>
			</div>
		</div>
    </header>
	<div align="center" class="span6 Absolute-Center" style="" >
					<div class="thumbnail" id="" style="padding:0px;border-radius:9px;">
						<form class="form-horizontal" role="form" style="margin:0px" id="login" >
					
							<div align="center" class="form-group" id="logincolour">
								
								<div class="logincss" >
								
								<table style="border-radius:7px;width:100%" class="color"  >
									<tr>						
										<td  colspan = "3" style="background:#d8d8d8;border-radius:5px">
											<h4  align="center"><b>Login</b></h4>
										</td>	
									</tr>
									<tr style="height:10px">
										<td>
										</td>
									</tr>							
									<tr>
										<td>
												<label for="inputEmail3" class="col-sm-2 control-label">Email</label>
										</td>
										<td style="width:50%">
												<div class="input-group">
													<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
													<input type="email" class="form-control" id="inputEmail3" placeholder="Email">
												</div>
										</td>
										<td style="width:10%">
										</td>
									</tr>
									<tr style="height:10px">
										<td>
										</td>
									</tr>
									<tr>
										<td>
												<label for="inputPassword3" class="col-sm-2 control-label">Password</label>
										</td>
										<td style="width:50%">
												<div class="input-group">
													<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
													<input type="password" class="form-control" id="inputPassword3" placeholder="Password">
												</div>
										</td>
										<td style="width:10%">
										</td>
									</tr>
									<tr style="height:10px">
										<td>
										</td>
									</tr>
									<tr>
										<td colspan = "3">
												<div class="col-sm-offset-2 col-sm-10" style="margin-left:30%">
												<button type="submit"  class="btn btn-default">Sign in</button>&emsp;&emsp;
												<button type="reset" class="btn btn-default">Reset</button>
												</div>
										</td>
									</tr>
									<tr style="height:10px">
										<td>
										
										</td>
									</tr>
									<tr>
										<td colspan = "3">
													<div class="col-sm-offset-2 col-sm-10" style="margin-left:30%">
														<a href="#" ><b><span style="color:#000">Forgot your password?</span></b></a>
													</div>
										</td>
									</tr>
									<tr>
										<td colspan = "3">
													<div class="col-sm-offset-2 col-sm-10" style="margin-left:34%;color:red">
														<b><span id="error"></span></b>
													</div>
										</td>
									</tr>
								</table>
								
								</div>
								
							</div>
							
							<!--<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<div class="checkbox">
										<label>
											<input type="checkbox"> Remember me
										</label>
									 </div>
								</div>
							</div>-->
							
						</form>	
						
					</div>
			
	</div>
</body>
</html>

<script>

$('form#login').submit(function(e){
   e.preventDefault();
    
	var email=document.getElementById("inputEmail3").value;
	var password=document.getElementById("inputPassword3").value;
	if(email=='admin@admin.com' && password=='admin' )
	{
	window.location.href='home.php';
	}
	else
	{
	document.getElementById('error').innerHTML="Invalid login data";
	}
	
   
 });
  
</script>